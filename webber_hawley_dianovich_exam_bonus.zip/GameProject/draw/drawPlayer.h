

void drawPlayer(int animFrame);

void drawPlayer(int animFrame) {
	glCallList(meshCharacterStanding01);
}