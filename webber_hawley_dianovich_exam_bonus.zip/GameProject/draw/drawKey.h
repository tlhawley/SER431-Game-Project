
void drawKey();

void drawKey() {
	//setMaterialAdvanced(materialGold);
	glCallList(meshKey);
}