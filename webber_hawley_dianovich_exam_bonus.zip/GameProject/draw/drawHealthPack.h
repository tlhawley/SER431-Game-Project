
void drawHealthPack();

void drawHealthPack(){
glCallList(drawList3);
}

