
void drawGem();

void drawGem() {
	glCallList(meshGem);
}