
void drawPortal();

void drawPortal() {
	glCallList(meshPortal);
}