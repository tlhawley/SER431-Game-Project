

void drawAL();

void drawAL() {
	glCallList(meshAL);
}