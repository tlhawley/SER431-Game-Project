
void drawPorsche();

void drawPorsche() {
	glCallList(meshPorsche);
}