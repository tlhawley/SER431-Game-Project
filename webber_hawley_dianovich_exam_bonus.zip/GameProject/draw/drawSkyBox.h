
void drawSkyBox();

void drawSkyBox() {
	glCallList(meshSkyBox);
}