
void drawMirror1();

void drawMirror1() {
	glCallList(meshLV1WaterMirror);
	//glCallList(meshq3MirrorPlane);
}