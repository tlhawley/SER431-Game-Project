

void drawRoomWall1();
void drawRoomWall2();

void drawRoomWall1() {
	glCallList(meshRoomWall1);
}

void drawRoomWall2() {
	glCallList(meshRoomWall2);
}

