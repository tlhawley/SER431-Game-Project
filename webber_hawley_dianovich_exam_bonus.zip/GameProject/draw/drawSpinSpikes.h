void drawSpinSpikes();

void drawSpinSpikes(){
	//glCallList(drawList2);
	glCallList(meshSpikes);
}