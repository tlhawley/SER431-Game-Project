void checkCollision();


void checkCollision()
{

	/*
	// Set Max Collision Bounds
	if (x > 28.5) x = 28.5;
	if (x < -28.5) x = -28.5;
	if (z > 28.5) z = 28.5;
	if (z < -28.5) z = -28.5;
	if (y > 9) y = 9;
	if (y < 1) {
		y = 1;
		yv = 0.0f;
		canJump = true;
	}

	// Corner Collision
	if (x > 8.5 && z > 8.5) {
		if (ox <= 8.5) x = 8.5;
		if (oz <= 8.5) z = 8.5;
	}

	if (x > 8.5 && z < -8.5) {
		if (ox <= 8.5) x = 8.5;
		if (oz >= -8.5) z = -8.5;
	}

	if (x < -8.5 && z > 8.5) {
		if (ox >= -8.5) x = -8.5;
		if (oz <= 8.5) z = 8.5;
	}

	if (x < -8.5 && z < -8.5) {
		if (ox >= -8.5) x = -8.5;
		if (oz >= -8.5) z = -8.5;
	}
	*/

}